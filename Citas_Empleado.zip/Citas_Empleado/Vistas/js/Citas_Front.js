let appointments = [];
let currentEditingId = null;
let currentView = 'month';
let currentDate = new Date();


document.addEventListener('DOMContentLoaded', () => {
    fetchAppointments();
    showView(currentView);
    document.getElementById('appointmentForm').addEventListener('submit', handleFormSubmit);
});

function fetchAppointments() {
    fetch('http://localhost:3000/Controller/API_Controller.php')
        .then(res => res.json())
        .then(data => {
            appointments = data.map(app =>({
                ...app,
                id: app.id.toString(),
                status: app.status || 'pending'
            }));
            showView(currentView);
        })
        .catch(err => console.error('Error fetching appointments:', err));
}

function postAppointment(formData) {
    const url = 'http://localhost:3000/Controller/API_Controller.php';
    const method = formData.id ? 'PUT' : 'POST'; 

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(res => res.json())
    .then(() => {
        fetchAppointments();
        showNotification(formData.id ? 'Cita actualizada!' : 'Cita guardada!');
        hideModal();
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Error: ${err.message}', 'error');
    });
}

function handleFormSubmit(e) {
    e.preventDefault();
    const formData = {
        date: e.target.elements.date.value,
        time: e.target.elements.time.value,
        client: e.target.elements.client.value,
        vehicle: e.target.elements.vehicle.value,
        service: e.target.elements.service.value
    };

    const errors = validateForm(formData);
    if (errors.length > 0) {
        showNotification(errors.join(', '), 'error');
        return;
    }

    if (currentEditingId) formData.id = currentEditingId;

    console.log(formData);
    postAppointment(formData);
}

function changeMonth(offset) {
    currentDate.setMonth(currentDate.getMonth() + offset);
    generateCalendar(currentDate);
}

function generateCalendar(date) {
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = '';
    
    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const daysOfWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    const headerHTML = `
    <div class="calendar-nav">
        <button class="btn btn-flex" onclick="changeMonth(-1)"><</button>
        <h2>${monthNames[date.getMonth()]} ${date.getFullYear()}</h2>
        <button class="btn btn-flex" onclick="changeMonth(1)">></button>
    </div>
`;

    let calendarGridHTML = '<div class="calendar-grid">';
    calendarGridHTML += daysOfWeek.map(day => `<div class="calendar-header">${day}</div>`).join('');
    
    let day = new Date(date);
    day.setDate(1);
    day.setDate(day.getDate() - day.getDay());
    
    for(let i = 0; i < 42; i++) {
        const isOtherMonth = day.getMonth() !== date.getMonth();
        const isToday = day.toDateString() === new Date().toDateString();
        calendarGridHTML += `
            <div class="calendar-day ${isOtherMonth ? 'other-month' : ''} ${isToday ? 'current-day' : ''}">
                <strong>${day.getDate()}</strong>
                ${renderDailyAppointments(day)}
            </div>
        `;
        day.setDate(day.getDate() + 1);
    }
    
    calendarGridHTML += '</div>';
    calendarView.innerHTML = headerHTML + calendarGridHTML;
}

function generateWeekView() {
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());
    
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = '';
    
    for(let i = 0; i < 7; i++) {
        const currentDay = new Date(startOfWeek);
        currentDay.setDate(startOfWeek.getDate() + i);
        
        calendarView.innerHTML += `
            <div class="week-day">
                <h3>${currentDay.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric' })}</h3>
                ${renderDailyAppointments(currentDay)}
            </div>
        `;
    }
    calendarView.innerHTML += '</div>';
}


function generateDayView(selectedDate = new Date()) {
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = `
        <div class="day-view">
            <button class="btn btn-primary" onclick="showView('month')">← Volver</button>
            <h2>${selectedDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</h2>
            ${renderDailyAppointments(selectedDate)}
        </div>
    `;
}


/*function showDailyAppointments(dateString) {
    const date = new Date(dateString);
    const dailyAppointments = appointments.filter(app => 
        new Date(app.date).toDateString() === date.toDateString()
    );
    
    const modalTitle = document.getElementById('modalTitle');
    const appointmentsList = document.getElementById('dailyAppointmentsList');
    
    modalTitle.textContent = date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
    appointmentsList.innerHTML = dailyAppointments.map(app => `
        <div class="appointment-card">
            <h3>${app.service}</h3>
            <p>⏰ ${app.time} - 👤 ${app.client}</p>
            <p>🚗 ${app.vehicle}</p>
            <button class="btn btn-primary" onclick="editAppointment('${app.id}')">Editar</button>
        </div>
    `).join('');
    
    document.getElementById('dailyAppointmentsModal').style.display = 'flex';
}*/

function parseDBDate(dateString) {

    const [year, month, day] = dateString.split('-');
    return new Date(dateString + 'T12:00:00');

    /*const [year, month, day] = dateString.split('-');
    const date = new Date(year, month - 1, day);
    date.setDate(date.getDate()); 
    return date;*/
}

function renderDailyAppointments(date) {
    const dailyAppointments = appointments.filter(app => {
        try {
            const appDate = parseDBDate(app.date)
            return appDate.toDateString() === date.toDateString();
        } catch (e) {
            console.error('Error parsing date:', app.date, e);
            return false;
        }
});


return dailyAppointments.map(app => `
    <div class="appointment-card mini-card ${date.getMonth() !== currentDate.getMonth() ? 'no-click' : ''}
        ${app.status === 'completed' ? 'completed' : ''}"
        ${date.getMonth() === currentDate.getMonth() ? `onclick="showAppointmentDetails('${app.id}')"` : ''}>
        <small>${app.service}</small>
        <small>${app.time}</small>
    </div>
`).join('');

}

function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

function validateForm(formData) {
    const errors = [];
    const currentDate = new Date();
    const selectedDate = new Date(formData.date + 'T' + formData.time);

    if (!formData.date || !formData.time) errors.push('Fecha y hora requeridas');
    if (selectedDate < currentDate) errors.push('No se pueden agendar citas en el pasado');
    if (!formData.client.trim()) errors.push('Nombre del cliente requerido');
    if (!formData.vehicle.trim()) errors.push('Vehículo requerido');

    return errors;
}

function editAppointment(id) {
    const appointment = appointments.find(a => a.id === id);
    if (appointment) {
        currentEditingId = id;
        document.querySelector('input[name="date"]').value = appointment.date;
        document.querySelector('input[name="time"]').value = appointment.time;
        document.querySelector('input[name="client"]').value = appointment.client;
        document.querySelector('input[name="vehicle"]').value = appointment.vehicle;
        document.querySelector('select[name="service"]').value = appointment.service;
        showModal();
    }  else {
        console.error('No se encontro el ID:', id);
        showNotification('No se pudo cargar la cita para editar', 'error');
    }
}

function cancelAppointment(id) {    
    fetch(`http://localhost:3000/Controller/API_Controller.php?id=${id}`, {
        method: 'DELETE'
    })
    .then(async res => {
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || `Error ${res.status}`);
        }
        return res.json();
    })
    .then(() => {
        fetchAppointments();
        showNotification('Cita cancelada');
        hideModal();
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification(`Error al cancelar cita: ${err.message}`, 'error');
    });
}

function completeAppointment(id) {
    fetch('http://localhost:3000/Controller/API_Controller.php', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    })
    .then(async res => {
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || `Error ${res.status}`);
        }
        return res.json();
    })
    .then(() => {
        fetchAppointments();
        showNotification('Cita marcada como completada');
        hideModal();
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification(`Error: ${err.message}`, 'error');
    });
}

function renderAppointments() {
    if (currentView === 'month') return;
    
    const container = document.getElementById('calendarView');
    container.innerHTML = appointments.map(app => `
        <div class="appointment-card">
            <h3>${app.service}</h3>
            <ul class="appointment-details">
                <li>📅 Fecha: ${app.date}</li>
                <li>⏰ Hora: ${app.time}</li>
                <li>👤 Cliente: ${app.client}</li>
                <li>🚗 Vehículo: ${app.vehicle}</li>
                <li>🏷️ <span class="status-badge status-${app.status}">${app.status}</span></li>
            </ul>
            <button class="btn btn-primary" onclick="editAppointment('${app.id}')">Editar</button>
            <button class="btn btn-danger" onclick="cancelAppointment('${app.id}')">Cancelar</button>
        </div>
    `).join('');
}


function showView(view) {
    currentView = view;
    const calendarView = document.getElementById('calendarView');
    calendarView.className = `calendar-view ${view}-view`;
    
    switch(view) {
        case 'month':
            generateCalendar(currentDate);
            break;
        case 'week':
            generateWeekView();
            break;
        case 'day':
            generateDayView(new Date());
            break;
    }
}

function filterAppointments() {
    const filter = document.getElementById('filterSelect').value;

    if(filter === 'all'){
        showView("month")
    }else{
        const filtered = appointments.filter(app => app.status === filter);
        renderFilteredAppointments(filtered);
    }
}

function renderFilteredAppointments(filteredApps) {
    const container = document.getElementById('calendarView');
    container.innerHTML = filteredApps.map(app => `
        <div class="appointment-card ${app.status}">
            <h3>${app.service}</h3>
            <ul class="appointment-details">
                <li>📅 Fecha: ${app.date}</li>
                <li>⏰ Hora: ${app.time}</li>
                <li>👤 Cliente: ${app.client}</li>
                <li>🚗 Vehículo: ${app.vehicle}</li>
                <li>🏷️ <span class="status-badge status-${app.status}">${app.status}</span></li>
            </ul>
            ${app.status !== 'completed' ? 
                `<button class="btn btn-primary" onclick="editAppointment('${app.id}')">Editar</button>
                <button class="btn btn-success" onclick="completeAppointment('${app.id}')">Finalizar</button>` : ''}
                <button class="btn btn-danger" onclick="cancelAppointment('${app.id}')">Cancelar</button>
        </div>
    `).join('');
}

function showAppointmentDetails(id) {
    const numericId = typeof id === 'string' && !isNaN(id) ? Number(id) : id;
    const appointment = appointments.find(a => a.id == numericId); 

    if (!appointment) {
        console.error('Appointment not found with ID:', id, 'Available appointments:', appointments);
        showNotification('No se pudo encontrar la cita', 'error');
        return;
    }

    const modalTitle = document.getElementById('modalTitle');
    const appointmentsList = document.getElementById('dailyAppointmentsList');
    
    modalTitle.textContent = `Cita: ${appointment.service}`;
    appointmentsList.innerHTML = `
        <div class="appointment-card ${appointment.status === 'completed' ? 'completed' : ''}">
            <h3>${appointment.service}</h3>
            <p>📅 Fecha: ${appointment.date}</p>
            <p>⏰ Hora: ${appointment.time}</p>
            <p>👤 Cliente: ${appointment.client}</p>
            <p>🚗 Vehículo: ${appointment.vehicle}</p>
            <p>Estado: <span class="status-badge status-${appointment.status}">${appointment.status}</span></p>
            ${appointment.status !== 'completed' ? 
                `<button class="btn btn-primary" onclick="editAppointment('${appointment.id}')">Editar</button>
                <button class="btn btn-success" onclick="completeAppointment('${appointment.id}')">Finalizar</button>
                <button class="btn btn-danger" onclick="cancelAppointment('${appointment.id}')">Cancelar</button>` : ''}
            
        </div>
    `;
    
    document.getElementById('dailyAppointmentsModal').style.display = 'flex';
}

function showModal() {
    document.getElementById('newAppointmentModal').style.display = 'flex';
}

function hideModal() {
    document.getElementById('appointmentForm').reset();
    currentEditingId = null;
    document.getElementById('newAppointmentModal').style.display = 'none';
    document.getElementById('dailyAppointmentsModal').style.display = 'none';
}

window.onclick = function(event) {
    if (event.target.className === 'modal') {
        hideModal();
    }
}

