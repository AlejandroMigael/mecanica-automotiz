<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mecánica Rápida - Gestión de Citas</title>
    <link rel="stylesheet" href="css/CitasStyle.css">
    <?php include 'header.php';?>
</head>
<body>
    <div class="container">
        <div class="nav-buttons">
            <button class="btn btn-primary" onclick="showView('day')">Vista Diaria</button>
            <button class="btn btn-primary" onclick="showView('week')">Vista Semanal</button>
            <button class="btn btn-primary" onclick="showView('month')">Vista Mensual</button>
            <button class="btn btn-success" onclick="showModal()">Nueva Cita</button>
        </div>

        <div class="filter-container">
            <div class="filter-item">
                <h3>Filtrar por:</h3>
                <select id="filterSelect" onchange="filterAppointments()">
                    <option value="all">Todas las citas</option>
                    <option value="pending">Pendientes</option>
                    <option value="completed">Completadas</option>
                </select>
            </div>
        </div>

        <div class="calendar-view" id="calendarView"></div>

        <div class="modal" id="newAppointmentModal">
            <div class="modal-content">
                <span class="close-modal" onclick="hideModal()">&times;</span>
                <h2>Nueva Cita</h2>
                <form id="appointmentForm">
                    <div class="form-group">
                        <label>Fecha:</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label>Hora:</label>
                        <input type="time" name="time" required>
                    </div>
                    <div class="form-group">
                        <label>Cliente:</label>
                        <input type="text" name="client" required>
                    </div>
                    <div class="form-group">
                        <label>Vehículo:</label>
                        <input type="text" name="vehicle" required>
                    </div>
                    <div class="form-group">
                        <label>Servicio:</label>
                        <select name="service">
                            <option>Cambio de Aceite</option>
                            <option>Alineación</option>
                            <option>Frenos</option>
                            <option>Diagnóstico</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="modal" id="dailyAppointmentsModal">
            <div class="modal-content">
            <span class="close-modal" onclick="hideModal()">&times;</span>
             <h2 id="modalTitle"></h2>
             <div id="dailyAppointmentsList"></div>
             </div>
        </div>

        <div class="notification" id="notification"></div>
    </div>
    
    <script src="js/Citas_Front.js"></script>
</body>
</html>