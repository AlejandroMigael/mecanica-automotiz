<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>MecanicaCUT</title>
<link href="css/HomeStyle.css" rel="stylesheet" type="text/css"> 
</head>

<body>

<header role="banner" class="header">
      <div class="logo">
          <img
            src="Imagenes/Logo.png"
            alt="Logo"
            class="logo-img"
          />
      </div>
      <nav class="navbar">
        <ul>
          <li><a href="/">Inicio</a></li>
          <li class="dropdown">
          	<a class="dropbtn" href="/index.php">Citas<span class="caret"></span></a>
          </li>
           <li class="dropdown">
          	<a class="dropbtn">Ventas<span class="caret"></span></a>
          	<div class="dropdown-content">
          		<a href="Venta.php">Hacer Venta</a>
          		<a href="/Taller/Vistas/VerVenta.jsp">Ver Venta</a>
          	</div>
          </li>
          <li><a href="productos.php">Inventario</a></li>
          <li><a href="/Taller/Vistas/Login.jsp">Logout</a></li>
        </ul>
      </nav>
    </header>
    

</body>
</html>