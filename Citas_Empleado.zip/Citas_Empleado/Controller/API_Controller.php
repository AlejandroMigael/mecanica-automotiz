<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type");
date_default_timezone_set('America/Mexico_City');


require '..\Modelo\DB_Modal.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT *, DATE_FORMAT(date, '%Y-%m-%d') as date FROM prueba");
            //$stmt = $pdo->query("SELECT * FROM prueba");
            echo json_encode($stmt->fetchAll());
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(["error" => "Error al obtener citas", "mensaje" => $e->getMessage()]);
            }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            http_response_code(400);
            echo json_encode(["error" => "JSON inválido", "detalle" => json_last_error_msg()]);
            exit;
        }
        if (!$data || !isset($data['date'], $data['time'], $data['client'], $data['vehicle'], $data['service'])) {
            http_response_code(400);
            echo json_encode(["error" => "Missing required fields"]);
            exit;
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO prueba (date, time, client, vehicle, service, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['date'],
                $data['time'],
                $data['client'],
                $data['vehicle'],
                $data['service'],
                'pending'
            ]);
            $lastId = $pdo->lastInsertId();
            $stmt = $pdo->prepare("SELECT * FROM prueba WHERE id = ?");
            $stmt->execute([$lastId]);
            $newAppointment = $stmt->fetch();
            echo json_encode($newAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al insertar en la base de datos", "mensaje" => $e->getMessage()]);
        }
        break;
    
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data || !isset($data['id'])) {
            http_response_code(400);
            echo json_encode(["error" => "ID y datos requeridos para actualizar"]);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE prueba SET date = ?, time = ?, client = ?, vehicle = ?, service = ? WHERE id = ?");
            $stmt->execute([
                $data['date'],
                $data['time'],
                $data['client'],
                $data['vehicle'],
                $data['service'],
                $data['id']
            ]);
            
            $stmt = $pdo->prepare("SELECT * FROM prueba WHERE id = ?");
            $stmt->execute([$data['id']]);
            $updatedAppointment = $stmt->fetch();
            
            echo json_encode($updatedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al actualizar cita", "mensaje" => $e->getMessage()]);
        }
        break;


    case 'DELETE':
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "ID requerido"]);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM prueba WHERE id = ?");
            $stmt->execute([$id]);
            $deletedAppointment = $stmt->fetch();
            $stmt = $pdo->prepare("DELETE FROM prueba WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode($deletedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al eliminar cita", "mensaje" => $e->getMessage()]);
        }
        break;


    case 'PATCH':
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$data || !isset($data['id'])) {
            http_response_code(400);
            echo json_encode(["error" => "ID requerido"]);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE prueba SET status = ? WHERE id = ?");
            $stmt->execute(['completed', $data['id']]);
            $stmt = $pdo->prepare("SELECT * FROM prueba WHERE id = ?");
            $stmt->execute([$data['id']]);
            $updatedAppointment = $stmt->fetch();
            
            echo json_encode($updatedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al actualizar estado", "mensaje" => $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Método no permitido"]);
        break;
}